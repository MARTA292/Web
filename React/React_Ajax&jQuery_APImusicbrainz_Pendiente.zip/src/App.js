import React from 'react';
import axios from 'axios';
import './App.css'
import Title from './componentes/Title'
import Form from './componentes/Form'
import Tabla from "./componentes/TablaArtistas";
import Ficha from "./componentes/FichaArtista";

const api_root = "https://musicbrainz.org/ws/2/";
const api_cover_root = 'http://coverartarchive.org/';

class App extends React.Component {

  constructor(props) {
    super(props);

    this.state = {
      resultados: [],
      detalles: null
    }

    this.onSearch = this.onSearch.bind(this);
    this.onClicked = this.onClicked.bind(this);
  }

  onSearch(query) {
    // Lanzo la petición
    //${api_root}${entity}?query=${query}&limit=0&offset=${offset}&fmt=json
    const url = api_root + 'release-group?query=' + query + '&limit=0&offset=0';
    console.log(url);
    axios.get(url).then((r) => {
      this.setState({
        resultados: r["release-group"],
        detalles: null
      })
      console.log(this.state.resultados)
    }).catch((error) => {
      console.log(error); //Logs a string: Error: Request failed with status code 404
    });
  }

  onClicked(mdid, artista) {
    // Lanzo la petición
    console.log(mdid);
    axios.get(api_cover_root + 'release-group/' + mdid).then((r) => {
      this.setState({
        detalles: r.data
      });
    })
    .catch((error) => {
      console.log(error); //Logs a string: Error: Request failed with status code 404
    });
  }

  render() {
    if (this.state.detalles)
      return ( 
        <div class="container"> 
          <Form buscar = {this.onSearch}/>
          <br></br>
          <Ficha datos = {this.state.detalles}/>
        </div >
      );
    else if (this.state.resultados)
      return ( 
          <div class="container"> <br></br>
            <Title></Title><br></br>
            <Form buscar = { this.onSearch}/>
            <br></br>
            <Tabla cabecera = {
            ['Titulo ', 'Artista', 'Tipo']
            }
            filas = {
              this.state.resultados
            }
            onClicked = {
              this.onClicked
            }/> 
          </div>
        );
    else
      return ( <div class="container"> <br></br>
        <Title></Title><br></br>
        <Form buscar = { this.onSearch}/>
        <h5>No se ha encontrado ninguna coincidencia con la búsqueda</h5>
        </div >
      );
  }

}

export default App;