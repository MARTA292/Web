import React from 'react';
import './Title.css'

function Title() {
    return(
        <h1>Buscador de albumes en Musicbrainz</h1>
    );
} export default Title;
