import React from 'react';
import Grid from '@mui/material/Grid';
import TableCell from '@mui/material/TableCell';

function FichaArtista(props) {

    return (
        <Grid container spacing={3}>
            <Grid item xs={8}>
                <h1>{props.datos.name}</h1>
            </Grid>
            <Grid item xs={4}>
                <h2>{props.datos.title}</h2>
                
            </Grid>
            <Grid item xs={4}>
                <h2>{props.datos['first-release-date']}</h2>
                
            </Grid>
            <Grid item xs={12}>
                <TableCell><img width={128} src={props["caratula_release_group"]} alt='Caratura'/></TableCell>
            </Grid>
        </Grid>
    );
}
export default FichaArtista;

