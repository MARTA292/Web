const api_root = 'https://musicbrainz.org/ws/2/';
const api_cover_root = 'http://coverartarchive.org/';


function obtenerReleaseGroup(mbid, artista) {
    $("#tabla_resultados").hide();

    const url = `${api_cover_root}release-group/${mbid}`;
    $.get(url, (coverResponse) => {
        if (coverResponse.images.length > 0) {
            document.getElementById('caratula_release_group').src = coverResponse.images[0].image;
        } else {
            document.getElementById('caratula_release_group').src = "";
        }
    });

    $.get(`${api_root}release-group/${mbid}?fmt=json&inc=releases`, (r) => {
        $("#grid_ficha_release_group").show();
        $('#titulo_release_group').text(r.title);
        $('#lanzamiento_release_group').text(r['first-release-date']);  
    });

    $('#artista_release_group').text(artista);
}

function getResults(query) {
    // Vaciamos la tabla y ocultamos la ficha del album
    $('#table_body').empty();
    $('#headers_row').empty();
    $('#btnParent').empty();
    $("#grid_ficha_release_group").hide();

        const url = `${api_root}release-group?query=${query}&offset=0&fmt=json`;
        //console.log(url);
        $.get(url, (r) => {
        //console.log(r);
        const count = r.count;
        const r_offset = r.offset;
        const headers_row = document.getElementById('headers_row');

        $("#tabla_resultados").show();

            const thTitle = document.createElement('th');
            const thArtist = document.createElement('th');
            const thType = document.createElement('th');

            thTitle.innerText = 'Título';
            thArtist.innerText = 'Artista';
            thType.innerText = 'Tipo';

            headers_row.appendChild(thTitle);
            headers_row.appendChild(thArtist);
            headers_row.appendChild(thType);

            // Ordenamos los resultado indicando de que forma, en este caso por el valor del campo score en los valores json
            r['release-groups'].sort((a, b) => {
                return b.score - a.score;
            });

            // Nos fijamos que aquí no podemos acceder por el punto, ya que este valor tiene un guion en el medio, asi que accedemos usando clave.
            // Tambien hemos de fijarnos en el JSON devuelto, ya que hay una s en groups que no es como las entities que pasamos para la busqueda.
            r['release-groups'].forEach((resultado) => {
                const filaNueva = document.createElement('tr');
                const celdaTitle = document.createElement('td');
                const celdaArtist = document.createElement('td');
                const celdaType = document.createElement('td');

                celdaTitle.innerText = resultado.title;
                celdaArtist.innerText = resultado['artist-credit'][0].artist.name;
                celdaType.innerText = resultado['primary-type'];

                filaNueva.appendChild(celdaTitle);
                filaNueva.appendChild(celdaArtist);
                filaNueva.appendChild(celdaType);

                filaNueva.onclick = () => {
                    obtenerReleaseGroup(resultado.id, resultado['artist-credit'][0].artist.name);
                };


                document.getElementById('table_body').appendChild(filaNueva);

            });
        

   
        
    });
}

function buscar() {
    // Extraemos el término de búsqueda
    const query = encodeURIComponent(document.getElementById('input_busqueda').value);
    console.log(query);
       
    // Lanzo la petición
    getResults(query);
    
}
